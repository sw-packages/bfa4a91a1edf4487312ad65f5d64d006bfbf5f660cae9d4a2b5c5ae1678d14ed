#include "streamreader.h"

StreamReader::StreamReader() {}
